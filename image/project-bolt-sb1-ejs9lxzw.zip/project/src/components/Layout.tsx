import React from 'react';
import { Menu, Car, Users, ClipboardList, LogOut } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const [sidebarOpen, setSidebarOpen] = React.useState(false);

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 justify-between items-center">
            <div className="flex items-center">
              <button
                onClick={() => setSidebarOpen(!sidebarOpen)}
                className="p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100"
              >
                <Menu className="h-6 w-6" />
              </button>
              <h1 className="ml-4 text-xl font-semibold text-gray-900">
                Car Rental Management
              </h1>
            </div>
            <div className="flex items-center">
              <button className="flex items-center text-gray-500 hover:text-gray-700">
                <LogOut className="h-5 w-5 mr-2" />
                Logout
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside
          className={`${
            sidebarOpen ? 'translate-x-0' : '-translate-x-full'
          } fixed inset-y-0 left-0 transform bg-white w-64 transition duration-200 ease-in-out lg:translate-x-0 lg:static lg:inset-0 z-50`}
        >
          <nav className="mt-5 px-2">
            <a
              href="#"
              className="group flex items-center px-2 py-2 text-base font-medium rounded-md text-gray-900 hover:bg-gray-100"
            >
              <ClipboardList className="mr-4 h-6 w-6" />
              Rental Requests
            </a>
            <a
              href="#"
              className="mt-1 group flex items-center px-2 py-2 text-base font-medium rounded-md text-gray-900 hover:bg-gray-100"
            >
              <Car className="mr-4 h-6 w-6" />
              Cars
            </a>
            <a
              href="#"
              className="mt-1 group flex items-center px-2 py-2 text-base font-medium rounded-md text-gray-900 hover:bg-gray-100"
            >
              <Users className="mr-4 h-6 w-6" />
              Admins
            </a>
          </nav>
        </aside>

        {/* Main content */}
        <main className="flex-1 p-4">{children}</main>
      </div>
    </div>
  );
}