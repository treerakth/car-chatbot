export interface Car {
  id: number;
  model: string;
  licensePlate: string;
  status: 'available' | 'reserved';
  imageUrl: string;
}

export interface RentalRequest {
  id: number;
  userId: string;
  carId: number;
  startDate: string;
  endDate: string;
  status: 'pending' | 'approved' | 'in_use' | 'returned';
  createdAt: string;
  updatedAt: string;
}

export interface User {
  id: number;
  username: string;
  role: 'super_admin' | 'admin';
  createdAt: string;
}